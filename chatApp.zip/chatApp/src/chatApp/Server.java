package chatApp;

import java.net.*;
import java.util.Scanner;
import java.io.*;

public class Server {
  public static void main(String... args) throws IOException {

    int port = 0;
    int timeout = 0;
    Scanner stdIn = new Scanner (new InputStreamReader ( System.in ) );
    try {
    	System.out.println("Specify the port number:");
        port = Integer.parseInt(stdIn.nextLine());
        System.out.println("Specify the timeout number in seconds:");
        timeout = Integer.parseInt(stdIn.nextLine());
    }catch(Exception e) {
    	System.out.println("Could not scan the port number and/or timeout number!");
    }
    
    System.out.println("Waiting for client...");

    try {
    	ServerSocket serverSocket = new ServerSocket(port);
        Socket clientSocket = serverSocket.accept();   		
    	clientSocket.setSoTimeout(timeout*1000); //converting seconds to milliseconds
    	PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
        BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
    	System.out.println ( "Socket adress of the Client: " + clientSocket.getRemoteSocketAddress() );
    	System.out.println("Write 'see you later' to end the chat.");
        String inputLine =" ";
        String userInput =" ";
        String input=" "; // to finish the conversation
        while(!input.equals("see you later")) {
        	try {
        		inputLine = in.readLine();
        		clientSocket.setSoTimeout(0);
        	}catch(Exception e) {
        		System.out.println ( "Time has expired to communicate! " );
        		break;
        	}
        	
        	input=inputLine;
        	System.out.println ( "Client: " + inputLine );
        	if(!input.equals("see you later")) {
        		userInput = stdIn.nextLine();
                out.println ( userInput );
                input=userInput;
        	}
        }
        clientSocket.close();
        out.close();
        in.close();
        stdIn.close();
        serverSocket.close();
    }catch(IOException e) {
    	e.printStackTrace();
    }
  }
}
