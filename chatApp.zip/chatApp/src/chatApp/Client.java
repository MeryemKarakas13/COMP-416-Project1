package chatApp;

import java.io.*;
import java.net.*;
import java.util.*;

public class Client {
  public static void main ( String... args ) throws IOException {

    String host = "localhost";
    int port = 0;
    Scanner stdIn = new Scanner (new InputStreamReader ( System.in ) );
    System.out.println("Specify the port number:");
    try {
        port = Integer.parseInt(stdIn.nextLine());
    }catch(Exception e) {
    	System.out.println("Could not scan the port number!");
    }
    
    System.out.println("Specify the host address:");
    try {
    	host = stdIn.nextLine();
    }catch(Exception e) {
    	System.out.println("Could not scan the host address!");
    }

      
    try {
        Socket clientSocket = new Socket ( host, port );
    	System.out.println ( "Socket adress of the Server: " + clientSocket.getRemoteSocketAddress() );
    	//write data to socket
        PrintWriter out = new PrintWriter ( clientSocket.getOutputStream (), true );
    	//read data from socket
        BufferedReader in = new BufferedReader (new InputStreamReader ( clientSocket.getInputStream () ) );
    
        System.out.println("Write something to the server or write 'see you later' to end the chat.");
    	String inputLine =" ";
        String userInput =" ";
        String input=" "; // to finish the conversation
        while(!input.equals("see you later")) {
        	userInput = stdIn.nextLine();
            out.println ( userInput );
            input=userInput;
        	if(!input.equals("see you later")) {
        		try {
        			inputLine = in.readLine();
            	}catch(Exception e) {
            		System.out.println ( "Time has expired to communicate! " );
            		break;
            	}
            	input=inputLine;
            	System.out.println ( "Server: " + inputLine );
        	}
        }
        clientSocket.close();
        out.close();
        in.close();
        stdIn.close();
    }catch(IOException e) {
    	e.printStackTrace();
    }
  }
}
